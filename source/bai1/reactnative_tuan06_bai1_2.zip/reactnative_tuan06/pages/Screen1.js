import { StyleSheet, Text, View, Image,TouchableOpacity } from 'react-native';
import {useState, useEffect} from 'react'
import {Ionicons} from '@expo/vector-icons';
import axios from 'axios';
// You can import supported modules from npm
import { Card } from 'react-native-paper';
import blue from '../assets/vs_blue.png'
import black from '../assets/vs_black.png'
import red from '../assets/vs_red.png'
import silver from '../assets/vs_silver.png'
export default function Screen1({ navigation, route }) {
   const [color, setColor] = useState("blue");
  const [phoneData, setPhoneData] = useState(null);
  const [colorImages, setColorImages] = useState([]);
  useEffect(() => {
    const fetchColorData = async () => {
      try {
        const response = await axios.get('https://67cd35e2dd7651e464eda65e.mockapi.io/phones');
        setColorImages(response.data); 
      } catch (error) {
        console.error('Error fetching color data:', error);
      }
    };

    fetchColorData();
  }, []);
  // Chọn ảnh tương ứng với màu
  const getImageSource = () => {
    const selectedColor = colorImages.find(item => item.name === color);
    return selectedColor ? selectedColor.imgURL : null;
  };

  useEffect(() => {
    if (route.params?.color) {
      setColor(route.params.color);
    }
  }, [route.params?.color]);


  return (
    <View style={styles.container}>
      <Image   source={getImageSource()}  style={{width: "100vw" , height: 354, marginBottom:5, flex:1}}         resizeMode="contain"></Image>
      <View style={{flex:1}}>
        <Text>Điện Thoại Vsmart Joy 3 - Hàng chính hãng</Text>
        <View style={{flexDirection:"row", gap:5,marginVertical:5 }}>
          <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
          <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
          <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
          <View>  <Ionicons name="star" size={15} color="#fbe41b" /></View>
          <View>  <Ionicons name="star" size={15} color="#c4c4c4" /></View>
          <Text>(Xem 828 đánh giá)</Text>
        </View>
        <View style={{flexDirection:"row",justifyContent:"space-between"}}>
          <Text style={{fontWeight: "bold"}}>1.790.000 đ</Text>
          <Text style={{fontWeight: "bold", textDecorationLine: "line-through", color:"#c4c4c4"}}>1.790.000 đ</Text>
        </View>
        <View style={{flexDirection:"row", gap:10, marginTop:10}}>
          <Text style={{color:"red",fontWeight:"bold", textTransform:"uppercase"}}>Ở đâu rẻ hơn hơn hoàn tiền</Text>
           <Ionicons name="help-circle-outline" size={20} color="#000" fontWeight="bold"/>
        </View>
         <TouchableOpacity style={{ borderRadius:5, borderColor:"#000", borderWidth:1, justifyContent:"center", alignItems:"center", paddingVertical:10, textTransform:"uppercase", marginTop:10, flexDirection:"row"}}
         onPress={() => navigation.navigate('Screen2')}
         >
            4 Màu - chọn màu <Ionicons name="chevron-forward-outline" size={20} color="#000" fontWeight="bold"/>
          </TouchableOpacity>
      </View>
      <View>
        <TouchableOpacity style={{ borderRadius:5, color:"#fff", fontWeight:"bold", justifyContent:"center", alignItems:"center", paddingVertical:10, textTransform:"uppercase", marginTop:10, flexDirection:"row", backgroundColor:"red"}}>
            Chọn mua
          </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center',
    backgroundColor: '#fff',
    padding: 8,
  },
});
