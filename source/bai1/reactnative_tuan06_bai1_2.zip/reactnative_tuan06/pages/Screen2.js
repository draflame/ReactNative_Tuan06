import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import axios from 'axios'; // Make sure axios is imported
import { Ionicons } from '@expo/vector-icons';

export default function Screen2({ navigation, route }) {
  const [color, setColor] = useState("blue");
  const [colorImages, setColorImages] = useState([]); // State to store fetched data

  useEffect(() => {
    // Fetch color data from API
    const fetchColorData = async () => {
      try {
        const response = await axios.get('https://67cd35e2dd7651e464eda65e.mockapi.io/phones');
        setColorImages(response.data); // Store the color data
      } catch (error) {
        console.error('Error fetching color data:', error);
      }
    };

    fetchColorData(); // Call the API to fetch color data
  }, []);

  // Chọn ảnh tương ứng với màu
  const getImageSource = () => {
    const selectedColor = colorImages.find(item => item.name === color);
    return selectedColor ? selectedColor.imgURL : null;
  };

  if (colorImages.length === 0) {
    return (
      <View style={styles.container}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Hiển thị ảnh điện thoại theo màu đã chọn */}
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <Image
          source={{ uri: getImageSource() }} // Fetch image from the API dynamically
          style={{ width: 100, height: 100, marginBottom: 5 }}
          resizeMode="contain"
        />
        <Text style={{ marginLeft: 10 }}>Điện Thoại Vsmart Joy 3 Hàng chính hãng</Text>
      </View>

      {/* Khối chọn màu */}
      <View style={{ flex: 1, backgroundColor: "#c5c5c5", padding: 10 }}>
        <Text style={{ textTransform: "uppercase", fontWeight: 'bold', marginBottom: 10 }}>
          Chọn 1 màu bên dưới
        </Text>

        {/* Các nút chọn màu */}
        <View style={{ alignItems: "center" }}>
          {colorImages.map(item => (
            <TouchableOpacity
              key={item.id} // Use unique key for each button
              style={[styles.colorButton, { backgroundColor: item.name }]}
              onPress={() => setColor(item.name)} // Set color on press
            >
              {/* Optionally you can add an icon or text in each button */}
            </TouchableOpacity>
          ))}

          <TouchableOpacity
            style={{
              backgroundColor: "#2596be",
              width: "100%",
              padding: 10,
              borderRadius: 10,
              marginTop: "auto",
              justifyContent: "center",
              alignItems: "center"
            }}
            onPress={() => navigation.navigate('Screen1', { color })} // Pass color to Screen1
          >
            <Text style={{ fontWeight: "bold", color: "white" }}>Xong</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 8,
  },
  colorButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
    width: 80,
    height: 80
  },
});
