import * as React from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image, ActivityIndicator } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

// ----- Tab1: Products -----
function ProductsScreen({ navigation }) {
  const [products, setProducts] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch("https://68d63b35c2a1754b4269f2ed.mockapi.io/data")
      .then((res) => res.json())
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.item}
      onPress={() =>
        navigation.navigate("ProductDetails", {
          id: item.id,
          name: item.productName,
          price: item.price,
          img: item.img,
          description: item.description,
        })
      }
    >
      <Image source={{ uri: item.img }} style={styles.img} />
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{item.productName}</Text>
        <Text style={styles.price}>${item.price}</Text>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#007AFF" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
    </View>
  );
}

// ----- Tab2: Favorites -----
function FavoritesScreen() {
  return (
    <View style={styles.center}>
      <Text style={styles.empty}>⭐ Danh sách yêu thích trống</Text>
    </View>
  );
}

// ----- Product Details -----
function ProductDetailsScreen({ route }) {
  const { id, name, price, img, description } = route.params;
  return (
    <View style={styles.center}>
      <Image source={{ uri: img }} style={styles.detailImg} />
      <Text style={styles.detailsTitle}>{name}</Text>
      <Text style={styles.detailsText}>Mã SP: {id}</Text>
      <Text style={styles.detailsText}>Giá: ${price}</Text>
      <Text style={styles.detailsDesc}>{description}</Text>
    </View>
  );
}

// ----- Navigation Setup -----
const Tab = createBottomTabNavigator();
function HomeTabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Products" component={ProductsScreen} />
      <Tab.Screen name="Favorites" component={FavoritesScreen} />
    </Tab.Navigator>
  );
}

const Stack = createNativeStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="HomeTabs" component={HomeTabs} options={{ title: "Trang chủ" }} />
        <Stack.Screen
          name="ProductDetails"
          component={ProductDetailsScreen}
          options={{ title: "Chi tiết sản phẩm" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// ----- Styles -----
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 12,
    backgroundColor: "#f9f9f9",
  },
  item: {
    flexDirection: "row",
    backgroundColor: "#fff",
    padding: 12,
    marginBottom: 12,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 3,
    alignItems: "center",
  },
  img: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: "600",
  },
  price: {
    fontSize: 14,
    color: "#666",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  empty: {
    fontSize: 16,
    color: "#999",
  },
  detailImg: {
    width: 200,
    height: 200,
    borderRadius: 12,
    marginBottom: 16,
  },
  detailsTitle: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 12,
  },
  detailsText: {
    fontSize: 16,
    marginBottom: 6,
  },
  detailsDesc: {
    fontSize: 14,
    color: "#555",
    marginTop: 8,
    textAlign: "center",
  },
});


