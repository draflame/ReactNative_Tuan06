import * as React from "react";
import { View, Text, StyleSheet, Switch } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";

// ----- Home Screen -----
function HomeScreen() {
  return (
    <View style={styles.center}>
      <Text style={styles.title}>🏠 Welcome to Home</Text>
    </View>
  );
}

// ----- Profile Screen -----
function ProfileScreen() {
  return (
    <View style={styles.center}>
      <Text style={styles.title}>👤 User Profile</Text>
      <Text style={styles.text}>Name: John Doe</Text>
      <Text style={styles.text}>Email: john@example.com</Text>
    </View>
  );
}

// ----- Settings Screen -----
function SettingsScreen() {
  const [isEnabled, setIsEnabled] = React.useState(false);

  return (
    <View style={styles.center}>
      <Text style={styles.title}>⚙️ Settings</Text>
      <View style={styles.row}>
        <Text style={styles.text}>Dark Mode</Text>
        <Switch
          value={isEnabled}
          onValueChange={setIsEnabled}
        />
      </View>
    </View>
  );
}

// ----- Drawer Setup -----
const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator>
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Profile" component={ProfileScreen} />
        <Drawer.Screen name="Settings" component={SettingsScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

// ----- Styles -----
const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 16,
  },
  text: {
    fontSize: 16,
    marginBottom: 8,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 12,
    gap: 12,
  },
});

