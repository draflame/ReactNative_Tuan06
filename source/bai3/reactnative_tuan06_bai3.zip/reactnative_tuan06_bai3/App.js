// App.js
import React, { useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  Text,
  FlatList,
  Image,
  ActivityIndicator,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  StatusBar,
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons"; // optional

// ---------------- HomeScreen ----------------
function HomeScreen() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://67cd35e2dd7651e464eda65e.mockapi.io/user")
      .then((res) => res.json())
      .then((users) => setData(users || []))
      .catch((err) => console.error("Lỗi khi tải dữ liệu:", err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#60a5fa" />
        <Text style={styles.loadingText}>Đang tải...</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Danh sách người dùng</Text>
      <Text style={styles.subtitle}>Khám phá cộng đồng của chúng tôi</Text>

      <FlatList
        data={data}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 12 }}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card}>
            <Image
              source={
                item.avatar
                  ? { uri: item.avatar }
                  : { uri: "https://via.placeholder.com/100" }
              }
              style={styles.avatar}
            />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.status}>Đang hoạt động</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#cbd5e1" />
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

// ---------------- SearchScreen ----------------
function SearchScreen() {
  const [keyword, setKeyword] = useState("");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://67cd35e2dd7651e464eda65e.mockapi.io/user")
      .then((res) => res.json())
      .then((users) => setData(users || []))
      .catch((err) => console.error("Lỗi khi tải dữ liệu:", err))
      .finally(() => setLoading(false));
  }, []);

  // lọc dữ liệu theo từ khóa
  const filtered = data.filter((user) =>
    user.name.toLowerCase().includes(keyword.toLowerCase())
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#60a5fa" />
        <Text style={styles.loadingText}>Đang tải...</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Tìm kiếm</Text>
      <Text style={styles.subtitle}>Tìm kiếm người dùng theo tên</Text>

      {/* ô tìm kiếm */}
      <View style={styles.searchBox}>
        <Ionicons name="search" size={18} color="#94a3b8" style={{ marginLeft: 8 }} />
        <TextInput
          style={styles.searchInput}
          placeholder="Nhập từ khóa tìm kiếm..."
          placeholderTextColor="#94a3b8"
          value={keyword}
          onChangeText={setKeyword}
        />
      </View>

      {/* kết quả */}
      {filtered.length > 0 ? (
        <FlatList
          data={filtered}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ paddingVertical: 12 }}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.card}>
              <Image
                source={
                  item.avatar
                    ? { uri: item.avatar }
                    : { uri: "https://via.placeholder.com/100" }
                }
                style={styles.avatar}
              />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.status}>Đang hoạt động</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#cbd5e1" />
            </TouchableOpacity>
          )}
        />
      ) : (
        <View style={styles.center}>
          <Text style={styles.noResult}>Không tìm thấy kết quả phù hợp</Text>
        </View>
      )}
    </View>
  );
}


// ---------------- ProfileScreen ----------------
function ProfileScreen() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://67cd35e2dd7651e464eda65e.mockapi.io/user/1")
      .then((res) => res.json())
      .then((data) => setUser(data))
      .catch((err) => console.error("Lỗi khi tải dữ liệu người dùng:", err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#60a5fa" />
        <Text style={styles.loadingText}>Đang tải thông tin...</Text>
      </View>
    );
  }

  if (!user) {
    return (
      <View style={styles.center}>
        <Text style={styles.loadingText}>Không tìm thấy người dùng</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Hồ sơ</Text>
      <Text style={styles.subtitle}>Thông tin cá nhân của bạn</Text>

      <View style={styles.profileCard}>
        <Image
          source={user.avatar ? { uri: user.avatar } : { uri: "https://via.placeholder.com/150" }}
          style={styles.profileAvatar}
        />
        <Text style={styles.profileName}>{user.name}</Text>
        <Text style={styles.profileEmail}>user@example.com</Text>

        <View style={styles.statsRow}>
          <View style={styles.stat}>
            <Text style={styles.statNumber}>128</Text>
            <Text style={styles.statLabel}>Bài viết</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statNumber}>1.2K</Text>
            <Text style={styles.statLabel}>Người theo dõi</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statNumber}>456</Text>
            <Text style={styles.statLabel}>Đang theo dõi</Text>
          </View>
        </View>

        <TouchableOpacity style={styles.editButton}>
          <Text style={styles.editButtonText}>Chỉnh sửa hồ sơ</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ---------------- App (Tab navigation with TouchableOpacity) ----------------
export default function App() {
  const [activeTab, setActiveTab] = useState("Home");

  const tabs = [
    { name: "Home", label: "Home" },
    { name: "Search", label: "Search" },
    { name: "Profile", label: "Profile" },
  ];

  const ActiveComponent =
    activeTab === "Home" ? HomeScreen : activeTab === "Search" ? SearchScreen : ProfileScreen;

  return (
    <SafeAreaView style={styles.appContainer}>
      <StatusBar barStyle="light-content" backgroundColor="#0f172a" />
      <View style={{ flex: 1 }}>
        <ActiveComponent />
      </View>

      <View style={styles.tabBar}>
        {tabs.map((t) => {
          const isActive = t.name === activeTab;
          return (
            <TouchableOpacity
              key={t.name}
              style={styles.tabButton}
              onPress={() => setActiveTab(t.name)}
            >
              <Text style={[styles.tabLabel, isActive && { color: "#60a5fa" }]}>{t.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

// ---------------- Styles ----------------
const styles = StyleSheet.create({
  appContainer: { flex: 1, backgroundColor: "#0f172a" },
  screen: { flex: 1, padding: 12 },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  loadingText: { marginTop: 12, color: "#94a3b8" },

  title: { fontSize: 22, color: "#f8fafc", fontWeight: "700", marginBottom: 4 },
  subtitle: { color: "#94a3b8", marginBottom: 12 },

  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    backgroundColor: "#112233",
    borderRadius: 12,
    marginBottom: 10,
  },
  avatar: { width: 50, height: 50, borderRadius: 25, borderWidth: 2, borderColor: "#e2e8f0" },
  name: { color: "#f8fafc", fontSize: 16, fontWeight: "600" },
  status: { color: "#cbd5e1", marginTop: 4 },

  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#0f172a",
    borderColor: "#334155",
    borderWidth: 1,
    borderRadius: 10,
    height: 44,
  },
  searchInput: { flex: 1, paddingHorizontal: 8, color: "#fff" },

  subheading: { color: "#fff", fontSize: 16, fontWeight: "600", marginBottom: 8 },
  suggestion: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#0b254a",
    borderRadius: 8,
    marginBottom: 8,
  },
  resultText: { color: "#fff", fontSize: 16, marginBottom: 6 },
  noResult: { color: "#94a3b8" },

  profileCard: {
    marginTop: 12,
    backgroundColor: "#0b274b",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
  },
  profileAvatar: { width: 100, height: 100, borderRadius: 50, borderWidth: 3, borderColor: "#fff" },
  profileName: { color: "#fff", fontSize: 20, fontWeight: "700", marginTop: 10 },
  profileEmail: { color: "#cbd5e1", marginBottom: 12 },

  statsRow: { flexDirection: "row", justifyContent: "space-between", width: "100%", marginTop: 8 },
  stat: { alignItems: "center", flex: 1 },
  statNumber: { color: "#fff", fontSize: 16, fontWeight: "700" },
  statLabel: { color: "#cbd5e1" },

  editButton: {
    marginTop: 12,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#fff",
  },
  editButtonText: { color: "#fff", fontWeight: "600" },

  tabBar: {
    flexDirection: "row",
    borderTopWidth: 1,
    borderTopColor: "#334155",
    backgroundColor: "#1e293b",
  },
  tabButton: { flex: 1, paddingVertical: 12, alignItems: "center" },
  tabLabel: { color: "#94a3b8" },
});


